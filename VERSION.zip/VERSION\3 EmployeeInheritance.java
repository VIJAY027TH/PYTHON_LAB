//3. Employee Payroll System using Inheritance

import java.util.*;
class Employee {
String Emp_name, Emp_id, Address, Mail_id;
long Mobile_no; double BP;
Employee(String name, String id, String add, String mail, long mobile, double bp) { Emp_name = name;
Emp_id = id; Address = add; Mail_id = mail; Mobile_no = mobile;
BP = bp;}
void payslip() {
double DA = 0.97 * BP; double HRA = 0.10 * BP; double PF = 0.12 * BP;
double stafffund = 0.001 * BP; double gross = BP + DA + HRA; double net = gross - (PF + stafffund);
System.out.println("\n--- PAY SLIP ---");
System.out.println("Employee Name: " + Emp_name);
System.out.println("Employee ID: " + Emp_id);
System.out.println("Address: " + Address);
System.out.println("Mail Id: " + Mail_id);
System.out.println("Mobile No: " + Mobile_no);
System.out.println("Basic Pay: " + BP);
System.out.println("DA: " + DA);
System.out.println("HRA: " + HRA);
System.out.println("PF: " + PF);
System.out.println("Staff Club Fund: " + stafffund);
System.out.println("Gross Salary: " + gross);
System.out.println("Net Salary: " + net);}}
class Programmer extends Employee {
Programmer(String name, String id, String add, String mail, long mobile, double bp) { super(name, id, add, mail, mobile, bp);}}
class AssistantProfessor extends Employee {
AssistantProfessor(String name, String id, String add, String mail, long mobile, double bp) { super(name, id, add, mail, mobile, bp);}}
class AssociateProfessor extends Employee {
AssociateProfessor(String name, String id, String add, String mail, long mobile, double bp) {
super(name, id, add, mail, mobile, bp);}}
class Professor extends Employee {
Professor(String name, String id, String add, String mail, long mobile, double bp) { super(name, id, add, mail, mobile, bp);}}
public class EmployeeInheritance { public static void main(String[] args) {
Scanner sc = new Scanner(System.in); System.out.println("1. Programmer"); System.out.println("2. Assistant Professor"); System.out.println("3. Associate Professor"); System.out.println("4. Professor"); System.out.print("Enter choice: ");
int ch = sc.nextInt();
sc.nextLine();
System.out.print("Enter Name: "); String name = sc.nextLine(); System.out.print("Enter ID: "); String id = sc.nextLine(); System.out.print("Enter Address: "); String add = sc.nextLine(); System.out.print("Enter Mail Id: "); String mail = sc.nextLine();
System.out.print("Enter Mobile No: "); long mob = sc.nextLong(); System.out.print("EnterBasic Pay: "); double bp = sc.nextDouble();
Employee e; switch (ch) {
case 1: e = new Programmer(name, id, add, mail, mob, bp); break;
case 2: e = new AssistantProfessor(name, id, add, mail, mob, bp); break; case 3: e = new AssociateProfessor(name, id, add, mail, mob, bp); break; case 4: e = new Professor(name, id, add, mail, mob, bp); break;
default:
System.out.println("Invalid Choice"); return;}
e.payslip();}}


/*Sample Output
1.
Programmer
2.
Assistant Professor
3.
Associate Professor
4.
Professor
Enter choice: 1 Enter Name: Raj Enter ID: E101
Enter Address: Salem
Enter Mail Id: raj@gmail.com Enter Mobile No: 9876543210 Enter Basic Pay: 30000
--- PAY SLIP ---
Employee Name: Raj Employee ID: E101 Address: Salem
Mail Id: raj@gmail.com Mobile No: 9876543210
Basic Pay: 30000.0
DA: 29100.0
HRA: 3000.0
PF: 3600.0
Staff Club Fund: 30.0 Gross Salary: 62100.0
Net Salary: 58470.0*/