//7.Multithreaded Application for Processing Random Numbers

import java.util.Random;
class NumberGenerator extends Thread {
public void run() {
Random rand = new Random();
while (true) {
int num = rand.nextInt(100);
System.out.println("\nGenerated Number: " + num);
if (num % 2 == 0) { new Square(num).start(); }
else { new Cube(num).start(); }
try { Thread.sleep(1000); }
catch (InterruptedException e) { System.out.println(e); }
}
}
}
class Square extends Thread {
int num;
Square(int n) { num = n; }
public void run() {
System.out.println("Square of " + num + " = " + (num * num));
}
}
class Cube extends Thread {
int num;
Cube(int n) { num = n; }
public void run() {
System.out.println("Cube of " + num + " = " + (num * num * num));
}
}
public class MultiThreadDemo {
public static void main(String[] args) {
NumberGenerator t1 = new NumberGenerator();
t1.start();
}
}


/*Sample Output
Generated Number: 12
Square of 12 = 144
Generated Number: 7
Cube of 7 = 343
Generated Number: 26
Square of 26 = 676
Generated Number: 5
Cube of 5 = 125*/