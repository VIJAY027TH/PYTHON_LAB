import java.util.Scanner; public class LinearSearch {
public static void main(String[] args) {
Scanner sc = new Scanner(System.in);
System.out.print("Enter number of elements:");
int n = sc.nextInt();
int arr[] = new int[n];
System.out.println("Enterelements:");
for(int i=0; i<n; i++)
arr[i] = sc.nextInt();
System.out.print("Enter element to search: ");
int key = sc.nextInt();
int pos = -1;
for(int i=0; i<n; i++)
{
if(arr[i] == key) {
pos = i;
break;
}
}
if(pos == -1)
System.out.println(key + " not found"); else
System.out.println(key + " found at position " + (pos+1));
}}


/*Sample Output:
Enter number of elements:
5 Enter elements:
10 25 7 45 20
Enter element to search: 7 7 found at position 3*/