//1.D Insertion Sort

import java.util.Scanner;
public class InsertionSort {
public static void main(String[] args) {
Scanner sc = new Scanner(System.in);
System.out.print("Enter number of elements: ");
int n = sc.nextInt();
int arr[] = new int[n];
System.out.println("Enter elements:");
for(int i=0; i<n; i++)
arr[i] = sc.nextInt();
for (int i=1; i<n; i++) {
int key = arr[i]; int j = i - 1;
while(j >= 0 && arr[j] > key)
{ arr[j+1] = arr[j];
j--; }
arr[j+1] = key;}
System.out.println("Sorted Array:");
for(int x : arr)
System.out.print(x + " ");
} }

/*Sample Output
Enter number of elements: 5
Enter elements:
25 10 45 7 20
Sorted Array:
7 10 20 25 45*/