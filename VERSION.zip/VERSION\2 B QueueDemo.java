//2.B Queue Data Structures using Classes and Objects

import java.util.Scanner;
class Queue {
int max = 5;
int[] queue = new int[max];
int front = -1;
int rear = -1;
void enqueue(int item) {
if (rear == max - 1) { System.out.println("Queue Overflow"); }
else { if (front == -1) front = 0; queue[++rear] = item; System.out.println(item + " enqueued"); }
}
void dequeue() {
if (front == -1 || front > rear) { System.out.println("Queue Underflow"); }
else { System.out.println(queue[front] + " dequeued"); front++; }
}
void display() {
if (front == -1 || front > rear) { System.out.println("Queue Empty"); }
else { System.out.println("Queue Elements:"); for (int i = front; i <= rear; i++) { System.out.println(queue[i]); } }
}
}
public class QueueDemo {
public static void main(String[] args) {
Scanner sc = new Scanner(System.in);
Queue q = new Queue();
System.out.println("QUEUE OPERATIONS");
q.enqueue(100);
q.enqueue(200);
q.enqueue(300);
q.display();
q.dequeue();
q.display();
}
}


/*Sample Output
QUEUE OPERATIONS
100 enqueued
200 enqueued
300 enqueued
Queue Elements:
100
200
300
100
dequeued Queue Elements:
200
300*/