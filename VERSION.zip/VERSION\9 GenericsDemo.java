//9.The Features of Generic Classes

// Generic class
class GenericClass<T> { T value;
GenericClass(T val) { value = val;}
void display() {
System.out.println("Value: " + value);
System.out.println("Type: " + value.getClass().getName()); System.out.println();
} }
public class GenericsDemo {
public static void main(String[] args) {
// Integer type
GenericClass<Integer> obj1 = new GenericClass<>(100); obj1.display();
// String type
GenericClass<String> obj2 = new GenericClass<>("Hello Generics"); obj2.display();
// Double type
GenericClass<Double> obj3 = new GenericClass<>(15.75); obj3.display();
}}



/*Sample Output
Value: 100
Type: java.lang.Integer
Value: Hello Generics Type: java.lang.String
Value: 15.75
Type: java.lang.Double*/