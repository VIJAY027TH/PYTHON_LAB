//8.Basic File Operations

import java.io.*;
import java.util.*;
public class FileOperations {
public static void main(String[] args) { Scanner sc = new Scanner(System.in); try {
// Step 1: Create File System.out.print("Enter the file name: ");
String fname = sc.nextLine();
File file = new File(fname);
if (file.createNewFile()) {
System.out.println("File created successfully: " + file.getName());
} else {
System.out.println("File already exists.");
}
// Step 2: Write to File
System.out.println("Enter text to write to the file:"); String data = sc.nextLine();
FileWriter writer = new FileWriter(file); writer.write(data);
writer.close();
System.out.println("Data written to file successfully.");
// Step 3: Read from File System.out.println("\nReading data from file:");
Scanner reader = new Scanner(file);
while (reader.hasNextLine())
{ String line = reader.nextLine(); System.out.println(line);
}
reader.close();
} catch (IOException e) {
System.out.println("An error occurred."); e.printStackTrace();}}}


/*Sample Input / Output
Sample Input
Enter the file name: sample.txt Enter text to write to the file:
Welcome to Java File Handling!
Sample Output
File created successfully: sample.txt Data written to file successfully.
Reading data from file:
Welcome to Java File Handling!*/