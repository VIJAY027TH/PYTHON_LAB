//4.Abstract Class Shape

import java.util.Scanner;
abstract class Shape { int a, b;
abstract void printArea();}
class Rectangle extends Shape { Rectangle(int length, int breadth) {
a = length;
b = breadth;}
void printArea() {
System.out.println("Area of Rectangle: " + (a * b));}}
class Triangle extends Shape { Triangle(int base, int height) {
a = base;
b = height;}
void printArea() {
System.out.println("Area of Triangle: " + (0.5 * a * b));}}
class Circle extends Shape { Circle(int radius) {a = radius;}
void printArea() {
System.out.println("Area of Circle: " + (3.14 * a * a));}}
public class Main {
public static void main(String[] args) { Scanner sc = new Scanner(System.in);
System.out.print("Enter rectangle length & breadth: "); int l = sc.nextInt();
int b = sc.nextInt();
Shape r = new Rectangle(l, b); r.printArea();
System.out.print("Enter triangle base & height: "); int base = sc.nextInt();
int height = sc.nextInt();
Shape t = new Triangle(base, height); t.printArea();
System.out.print("Enter circle radius: ");
int radius = sc.nextInt();
Shape c = new Circle(radius);
c.printArea();}}


/*Sample Output
Enter rectangle length & breadth: 10 20
Area of Rectangle: 200
Enter triangle base & height: 10 15
Area of Triangle: 75.0
Enter circle radius: 5 Area of Circle: 78.5*/