//2 A Stack


import java.util.Scanner;
class Stack {
int max = 5;
int[] stack = new int[max];
int top = -1;
void push(int item) {
if (top == max - 1) {
System.out.println("Stack Overflow");
}
else {
stack[++top] = item;
System.out.println(item + " pushed");
}
}
void pop() {
if (top == -1) {
System.out.println("Stack Underflow");
}
else {
System.out.println(stack[top] + " popped");
top--;
}
}
void display() {
if (top == -1) {
System.out.println("Stack Empty");
}
else {
System.out.println("Stack Elements:");
for (int i = top; i >= 0; i--) {
System.out.println(stack[i]);
}
}
}
}
public class StackDemo {
public static void main(String[] args) {
Scanner sc = new Scanner(System.in);
Stack s = new Stack();
System.out.println("STACK OPERATIONS");
s.push(10);
s.push(20);
s.push(30);
s.display();
s.pop();
s.display();
}
}


/*o/p:
STACK OPERATIONS
10 pushed
20 pushed
30 pushed
Stack Elements:
30
20
10
30 popped
Stack Elements:
20
10*/