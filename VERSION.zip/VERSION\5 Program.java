//5.Shape using Interface

import java.util.Scanner;
interface Shape { void printArea(); }
class Rectangle implements Shape {
int length, breadth;
Rectangle(int l, int b) { length = l; breadth = b; }
public void printArea() { System.out.println("Area of Rectangle: " + (length * breadth)); }
}
class Triangle implements Shape {
double base, height;
Triangle(double b, double h) { base = b; height = h; }
public void printArea() { System.out.println("Area of Triangle: " + (0.5 * base * height)); }
}
class Circle implements Shape {
double radius;
Circle(double r) { radius = r; }
public void printArea() { System.out.println("Area of Circle: " + (3.14 * radius * radius)); }
}
public class Mainn {
public static void main(String[] args) {
Scanner sc = new Scanner(System.in);
System.out.print("Enter rectangle length & breadth: ");
int l = sc.nextInt();
int b = sc.nextInt();
Shape r = new Rectangle(l, b);
r.printArea();
System.out.print("Enter triangle base & height: ");
double ba = sc.nextDouble();
double h = sc.nextDouble();
Shape t = new Triangle(ba, h);
t.printArea();
System.out.print("Enter circle radius: ");
double rad = sc.nextDouble();
Shape c = new Circle(rad);
c.printArea();
}
}


/*output: 

Enter rectangle length & breadth: 10 20
Area of Rectangle: 200
Enter triangle base & height: 10 15
Area of Triangle: 75.0
Enter circle radius: 75.8
Area of Circle: 18041.3096*/