//1.B Binary Search

import java.util.Scanner;
public class BinarySearch {
public static void main(String[] args) { Scanner sc = new Scanner(System.in);
System.out.print("Enter number of elements: ");
int n = sc.nextInt();
int arr[] = new int[n];
System.out.println("Enter sorted elements:");
for(int i=0; i<n; i++) arr[i] = sc.nextInt();
System.out.print("Enter element to search: ");
int key = sc.nextInt();
int low = 0, high = n - 1, pos = -1;
while(low <= high) {
int mid = (low + high) / 2;
if(arr[mid] == key) { pos = mid;
break;
} else if(key < arr[mid]) { high = mid;
} else {
low = mid + 1;
}}
if(pos == -1)
System.out.println(key + " not found"); else

System.out.println(key + " found at position " + (pos+1));
}}

/*Sample Output
Enter number of elements: 5 Entersorted elements:
7 10 20 25 45
Enter element to search: 25 25 found at position 4*/