//6.Exception Handling & User-Defined Exceptions

import java.util.*;
// User Defined Exception
class InvalidAgeException extends Exception
{ InvalidAgeException(String msg)
{super(msg);}}
public class UserExceptionDemo
{ public static void main(String[] args) {
Scanner sc = new Scanner(System.in); int age;
System.out.print("Enter your age: "); age = sc.nextInt();
try {
if (age < 18) {
throw new InvalidAgeException("Age is less than 18 – Not Eligible!");
} else {
System.out.println("Eligible to Vote!");}}
catch (InvalidAgeException e) {
System.out.println("Exception Caught: " + e.getMessage());}
finally {
System.out.println("Program execution completed.");
}}}

/*Sample Output
Case 1
Enter your age: 16
Exception Caught: Age is less than 18 – Not Eligible! Program execution completed.
Case 2
Enter your age: 21 Eligible to Vote!
Program execution completed.*/