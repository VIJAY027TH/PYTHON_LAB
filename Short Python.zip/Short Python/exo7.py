print("EXCEPTION HANDLING")

try:
    # Taking two numbers as input
    num1, num2 = map(float, input("Enter two numbers separated by a comma: ").split(","))

    # Division operation
    result = num1 / num2
    print("Result:", result)

except ZeroDivisionError:
    print("Error: You cannot divide by zero!")
except ValueError:
    print("Error: Please enter two valid numbers separated by a comma.")
except Exception as e:
    print("Unexpected Error:", str(e))
else:
    print("No exceptions occurred.")
finally:
    print("\t*** End of program ***")
