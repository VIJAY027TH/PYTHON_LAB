class Student:
    count = 0  # Class variable to count students

    def __init__(self, name):
        self.name = name
        self.marks = []
        Student.count += 1  # Increment student count

    def enter_marks(self):
        self.marks = [int(input(f"Enter marks of {self.name} in subject {i + 1}: ")) for i in range(3)]

    def __str__(self):
        return f"{self.name} got {self.marks}"


# Creating multiple students dynamically
students = []
num_students = int(input("Enter the number of students: "))

for _ in range(num_students):
    name = input("\nEnter student name: ")
    student = Student(name)
    student.enter_marks()
    students.append(student)

# Displaying details
print("\nNumber of students in class:", Student.count)
for student in students:
    print(student)  # Calls __str__()
