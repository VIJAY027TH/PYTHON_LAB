print("Stack, Queue, and Tuple Operations")

# Stack implementation
stack = [10, 20, 30]
stack.extend([40, 50])
print("Stack after push:", stack)
print(stack.pop(), "popped")
print(stack.pop(), "popped")
print("Stack after pop:", stack)
print("Stack TOP:", stack[-1] if stack else "Empty")

# Queue implementation
queue = [1, 2, 3]
queue.extend([10, 100, 1000, 10000])
print("\nQueue after enqueue:", queue)
print(queue.pop(0), "dequeued")
print(queue.pop(0), "dequeued")
print("Queue after dequeue:", queue)
print("Front:", queue[0] if queue else "Empty", "| Rear:", queue[-1] if queue else "Empty")

# Tuple operations
Tuple1, Tuple2 = (5, 'Welcome', 7.5, 'Jairam'), (10, 20, 30, 40)
Tuple3, Tuple4 = Tuple1 + Tuple2, Tuple2 * 3
print("\nTuple Concatenation:", Tuple3)
print("Tuple Repetition:", Tuple4)
print("Tuple Slicing:", Tuple2[1:3], "| Reversed:", Tuple2[::-1])
