import re

print("\n\t📌 String Handling & Regular Expressions 📌\n")

# Email Validation
email = input("Enter your email ID: ")
pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'

if re.match(pattern, email):
    print("✅ Valid Email ID:", email)
else:
    print("❌ Invalid Email ID")

# Regular Expression Operations
print("\n\t🔍 Regular Expressions 🔍\n")

text = input("Enter your string: ")
print("Your String:", text)

# Splitting String by Whitespace
split_text = re.split(r"\s+", text)
print("📌 Split by whitespace:", split_text)

# Searching for a Substring
key = input("Enter the substring to search: ")
match = re.search(re.escape(key), text)

if match:
    print(f"✅ '{key}' found at position:", match.start())
else:
    print("❌ Substring not found.")
