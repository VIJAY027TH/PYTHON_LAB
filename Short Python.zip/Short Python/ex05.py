def add(a, b): return a + b

def subtract(a, b): return a - b

def multiply(a, b): return a * b

def divide(a, b): return a / b if b else "Cannot divide by zero"

def sum_avg(lst): return sum(lst), sum(lst) / len(lst) if lst else 0

a = int(input("Enter first number: "))
b = int(input("Enter second number: "))
nums = [10, 20, 30, 40, 50]

print("\nMathematical Operations \n")

print(f"{a} + {b} = {add(a, b)}")
print(f"{a} - {b} = {subtract(a, b)}")
print(f"{a} * {b} = {multiply(a, b)}")
print(f"{a} / {b} = {divide(a, b)}")

s, avg = sum_avg(nums)
print(f"Sum of [10, 20, 30, 40, 50] = {s}")
print (f"Average of [10, 20, 30, 40, 50] = {avg}")
