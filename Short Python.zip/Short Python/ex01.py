def calculate(op, a, b):
    if op == '1': return a + b
    if op == '2': return a - b
    if op == '3': return a * b
    if op == '4': return a / b if b else "Cannot divide by zero"
    return "Invalid operation"

while True:
    print("Select operation:\n1. Add\n2. Subtract\n3. Multiply\n4. Divide")
    op = input("Enter choice (1-4): ")
    a = int(input("Enter first number: "))
    b = int(input("Enter second number: "))
    print("Result:", calculate(op, a, b))
    if input("Continue? (y/n): ").lower() != 'y':
        break
