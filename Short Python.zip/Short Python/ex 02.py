print("Welcome to polling booth")

name = input("Enter your name: ")
age = int(input("Enter your age: "))
ward = int(input("Enter your ward number (1-3): "))

if age <= 0:
    print("Enter a valid age")
elif age < 18:
    print(f"Mr/Mrs. {name}, you are not eligible to vote")
elif age < 60:
    print(f"Mr/Mrs. {name}, you are eligible to vote at this polling booth")
    rooms = {1: 10, 2: 12, 3: 13}
    print(f"\tGoto Room Number {rooms.get(ward, 'Invalid ward')} and cast your vote" if ward in rooms else "Enter a valid ward number (1 to 3)")
else:
    print(f"Mr/Mrs. {name}, we suggest a postal vote due to the heavy crowd")

print("\t\tThanks for coming\nYou have exercised your democratic right")
