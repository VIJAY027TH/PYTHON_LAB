import os

print("FILE HANDLING PROGRAM IN PYTHON")

# Create a Directory
path = r"D:\Lab"
os.makedirs(path, exist_ok=True)  # Creates directory if not exists
print(f"Directory '{path}' is ready.")

# Writing content to a file
file_path = os.path.join(path, "sample.txt")
with open(file_path, "w") as file:
    file.write(input("Enter your text: "))

# Reading the content
with open(file_path, "r") as file:
    print("\nFile Content:\n", file.read())

print(f"\nCheck your file at {file_path}\n")

# Ask user if they want to delete the directory
if input("Delete the directory? (yes/no): ").lower() == "yes":
    os.remove(file_path)  # Delete the file first
    os.rmdir(path)  # Then remove the directory
    print("Directory deleted successfully.")
else:
    print("Directory not deleted.")
