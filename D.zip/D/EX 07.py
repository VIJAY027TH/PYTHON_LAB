print ("Exception Handling")

try:
    number1, number2 = eval(input("Enter Two Numbers Seprated By Comma: "))
    result = number1 / number2
    print("Result: ", result)

    if 1 ==0:
        raise RuntimeError
except ZeroDivisionError:
    print("Cannot Divide By Zero")
except SyntaxError:
    print("My be Comma is Missing")
except RuntimeError:
    print("My be Meaningless")
except:
    print("Something Wrong In the output")

else:
    print("No Exception")

finally:
    print("End Of Program")
        
