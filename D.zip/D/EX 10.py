import re

print ("Email Verifiacation and Regular Expresion")

email = input("Enter your Email-Id: ")
print("Valid Email ! " if re.match(r'\S+@\S+\.\S+',email) else "Invalid Input" )

text ,key = input("Enter Your String: "), input("Enter Your Search Sub-String: ")
match = re.search(key, text)
print("Result Found! ", match if match else "Not Found")
