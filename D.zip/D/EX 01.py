def vijay(c, a, b):
    if c == '1': return a + b
    if c == '2': return a - b
    if c == '3': return a * b
    if c == '4': return a / b if b else "Xannot Divide By Zero"
    return "Invalid Input"

while True:
    print("Select Your Operation\n 1.Add\n2.Subtract\n3.Multiply\n4.Divide ")
    c =input("Enter Your Operation (1-4): ")
    a = int(input("Enter The First Number: "))
    b = int(input("Enter The Second Number: "))
    print("Result: ",vijay(c, a,b))
    if input ("continue ? (y/n)").lower() != 'y':
        break
