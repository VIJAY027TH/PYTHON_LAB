import vijay

a = int(input("Enter The A Number: "))
b = int(input("Enter The B Number: "))

mylist = [10, 20, 30, 40, 50]
print("Elements are: ",mylist)

print(a,"+",b,"=",vijay.add(a,b))
print(a,"-",b,"=",vijay.sub(a,b))
print(a,"*",b,"=",vijay.mul(a,b))
print(a,"/",b,"=",vijay.div(a,b))


print("Sum of ",mylist,"=",vijay.my_sum(mylist))
print("Average of ",mylist,"=",vijay.avg(mylist))
