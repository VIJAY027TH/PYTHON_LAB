import os

path = r"D:\abc"
os.makedirs(path, exist_ok=True)
print(f"Directory {path} is ready.")

file_path=os.path.join(path, "Sample.txt")
with open (file_path,"w")as file:
    file.write(input("Enter Your String: "))
    
with open (file_path,"r")as file:
    print("Your Content is:  ",file.read())

print (f"Check Your File At:{file_path} ")


if input ("Delete the Directory? (yes/no)").lower()== 'yes':
    os.remove(file_path)
    os.rmdir(path)
    print("Directory Deleted Succesfully")
else:
    print("Directory Not Deleted")
 
