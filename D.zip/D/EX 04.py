print("Stack , Queue, and Tuple Operation")

stack = [10,20,30]
stack.extend([50])
print("Stack After Push: ",stack)
print(stack.pop(),"Popped")
print("Stack After Popped: ",stack)
print("Stack Top: ",stack[-1])


queue = [10,20,30]
queue.extend([50])
print("Queue After Enqueued: ",queue)
print(queue.pop(),"Dequeued")
print("Queue After Dequeued: ",queue)
print("Queue Top: ",queue[0])
print("Queue Rear: ",queue[-1])

tuple1 , tuple2  = (5, 'welcome' , 7.5, 'Jairam' ) , (10, 20, 30, 40)
tuple3 , tuple4 = tuple1 + tuple2 , tuple2 *3
print("Tuple Conteration: ",tuple3)
print("Tuple Repetaion: ",tuple4)
print("Tuple Slicing: ",tuple2[0:2])
print("Tuple Revesed: ",tuple2[::-1])                    
