print("Welcome To Pooling Booth")

name = input("Enter Your Name: ")
age = int(input("Enter Your Age: "))
ward = int(input("Enter Your Ward Number (1-3): "))

if age<18:
    print(f"Mr/Mrs. {name},You Are Not Eligible To vote")
elif age<=60:
    print(f"Mr/Mrs. {name},You Are Eligible To vote in this Pollin Booth")
    rooms = {1:10, 2:20, 3:30}
    print(f"GoTO Room Number {rooms.get(ward, 'Invalid Ward')}and cast Your vote" if ward in rooms else "Enter The Correct Ward Number")

else:
    print(f"Mr/Mrs. {name}, we are suggest You To vote Through Post Due To Heavy Crowd")

print("ThnakYou\n You Are Done With Your Domastic Right")
