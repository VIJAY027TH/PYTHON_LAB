class student:
    count = 0

    def __init__(self, name):
        self.name = name
        self.marks = [int(input(f"Enter The mark of {name} is subject {i + 1}")) for i in range(3)]
        student.count +=1

    def __str__(self):
        return f"{self.name} got {self.marks}"


student = [student(input("Enter The Name of the Student:  ")) for _ in range (int(input("Enter The Nmber of Students: ")))]
print(f"Number Of students in class {student.count}: ")
print(*student, sep="\n")
