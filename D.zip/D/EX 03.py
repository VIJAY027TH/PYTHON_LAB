print("Using For Loop")

for names in['vijay','ajay','jay']:
    print(names)

print("Using While Loop")

count = 1
while count <=5:
    print(count)
    count += 1
print("Using Do-while Loop")
n= int(input("Enter Your Number: "))
fact= 1
while n:
    fact *=n
    n -= 1
    print("factorial: ",fact)
